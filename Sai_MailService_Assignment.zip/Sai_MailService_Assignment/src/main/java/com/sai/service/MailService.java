package com.sai.service;

import com.sai.dto.MailRequest;

public interface MailService {

	String sendSimpleMail(MailRequest details);

}
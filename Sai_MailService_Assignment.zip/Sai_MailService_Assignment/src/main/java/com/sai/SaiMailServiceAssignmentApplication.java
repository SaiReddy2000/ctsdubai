package com.sai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaiMailServiceAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaiMailServiceAssignmentApplication.class, args);
	}

}

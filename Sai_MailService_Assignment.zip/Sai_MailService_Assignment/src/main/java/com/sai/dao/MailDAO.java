package com.sai.dao;

public interface MailDAO {

	String getRecipient();

}
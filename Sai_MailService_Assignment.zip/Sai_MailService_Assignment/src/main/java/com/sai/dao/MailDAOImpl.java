package com.sai.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sai.repository.LoginUserDetailsRepository;

@Repository
public class MailDAOImpl implements MailDAO {
	
	@Autowired
	private LoginUserDetailsRepository loginUserDetailsRepository;

	@Override
	public String getRecipient() {
		
		return loginUserDetailsRepository.findById(5).get().getEmail();
		
	}
	
}

express = require("express");
var app = express();
var bodyParser = require("body-parser");
const rest = require("request");
const { request } = require("express");
const { json } = require("body-parser");
const cors = require("cors");

app.use(bodyParser.json());

app.use(cors({ origin: "*" }));

app.use(bodyParser.urlencoded({ extended: true }));

app.get("/", function (req, res) {
  res.sendFile(__dirname + "/index.html");
});

app.get("/login/:userid/:password", function (req, resp) {
  var userid = req.params.userid;
  var password = req.params.password;
  data = { userId: userid, password: password };
  const options = {
    url: "http://localhost:8080/login/validate",
    method: "POST",
    body: JSON.stringify(data),
    headers: {
      "Content-Type": "application/json",
    },
  };

  rest(options, function (err, res, body) {
    message = JSON.parse(body).message;
    resp.send(message);
  });
});

app.get("/register/:userid/:email/:fname/:lname", function (req, resp) {
  var userid = req.params.userid;
  var email = req.params.email;
  var fname = req.params.fname;
  var lname = req.params.lname;
  data = { userId: userid, email: email, firstName: fname, lastName: lname };
  const options = {
    url: "http://localhost:8080/register/verify",
    method: "POST",
    body: JSON.stringify(data),
    headers: {
      "Content-Type": "application/json",
    },
  };

  rest(options, function (err, res, body) {
    message = JSON.parse(body).message;
    resp.send(message);
  });
});

app.get("/mail/:msgbody/:subject", function (req, resp) {
  var msgbody = req.params.msgbody;
  var subject = req.params.subject;
  data = { msgBody: msgbody, subject: subject };
  const options = {
    url: "http://localhost:8080/mail/sendmail",
    method: "POST",
    body: JSON.stringify(data),
    headers: {
      "Content-Type": "application/json",
    },
  };

  rest(options, function (err, res, body) {
    message = JSON.parse(body).message;
    resp.send(message);
  });
});

app.listen(80);
console.log("Server Started at Port 80");

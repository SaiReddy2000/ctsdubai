package com.sai.entity;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "loginuser")
public class LoginUser {

	@Id
	@Column(name = "loginid", length = 6)
	private Integer loginId; 

	@Column(name = "password", length = 10)
	private String password;

	@Column(name = "status", columnDefinition = "boolean default true")
	private Boolean status = true;

	@Column(name = "creationtime", columnDefinition = "timestamp default current_timestamp")
	private Date creationTime;
	
	@Column(name = "isnew", columnDefinition = "boolean default true")
	private Boolean isNew = true;
	
	@Column(name = "type", columnDefinition = "varchar(5) default 'User'")
	private String type = "User"; 
	
	@OneToOne(mappedBy = "loginUser" ,fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private LoginUserDetails loginUserDetails;

}

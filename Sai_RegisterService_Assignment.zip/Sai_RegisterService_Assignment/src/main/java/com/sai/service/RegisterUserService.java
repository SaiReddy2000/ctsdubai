package com.sai.service;

import com.sai.dto.RegisterRequest;

public interface RegisterUserService {

	String registerUser(RegisterRequest request);

}
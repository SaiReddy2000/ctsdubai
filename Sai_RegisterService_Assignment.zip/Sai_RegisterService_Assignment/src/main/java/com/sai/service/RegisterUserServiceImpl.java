package com.sai.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.dao.RegisterUserDAO;
import com.sai.dto.RegisterRequest;
import com.sai.entity.LoginUser;
import com.sai.entity.LoginUserDetails;

@Service
public class RegisterUserServiceImpl implements RegisterUserService {

	@Autowired
	private RegisterUserDAO dao;

	@Override
	public String registerUser(RegisterRequest request) {
		
		Integer loginId = request.getUserId();
		Optional<LoginUser> optional = dao.getUser(loginId);
		if (optional.isPresent()) {
			LoginUser loginUser = optional.get();
			if(loginUser.getType().equals("Admin")) {
				LoginUserDetails details = new LoginUserDetails(request.getUserId(),request.getLastName(),request.getFirstName(),request.getEmail(),loginUser);
				return dao.registerUser(details);
			} else {
				return "Access Denied - Admin Only";
			}
		}
		return "User ID is Wrong";
	}

}

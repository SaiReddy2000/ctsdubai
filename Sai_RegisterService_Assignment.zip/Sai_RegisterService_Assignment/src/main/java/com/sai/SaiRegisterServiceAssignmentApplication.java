package com.sai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaiRegisterServiceAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaiRegisterServiceAssignmentApplication.class, args);
	}

}

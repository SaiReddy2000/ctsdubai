package com.sai.dao;

import java.util.Optional;

import com.sai.entity.LoginUser;
import com.sai.entity.LoginUserDetails;

public interface RegisterUserDAO {

	Optional<LoginUser> getUser(Integer loginId);

	String registerUser(LoginUserDetails details);

}
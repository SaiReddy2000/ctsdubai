package com.sai.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sai.entity.LoginUser;
import com.sai.entity.LoginUserDetails;
import com.sai.repository.LoginUserDetailsRepository;
import com.sai.repository.LoginUserRepository;

@Repository
public class RegisterUserDAOImpl implements RegisterUserDAO {
	
	@Autowired
	private LoginUserRepository loginUserRepository;
	
	@Autowired
	private LoginUserDetailsRepository loginUserDetailsRepository;

	@Override
	public Optional<LoginUser> getUser(Integer loginId) {
		
		return loginUserRepository.findById(loginId);
		
	}

	@Override
	public String registerUser(LoginUserDetails details) {
		
		LoginUser loginUser = loginUserRepository.findById(details.getLoginId()).get();
		loginUser.setLoginUserDetails(details);
		loginUserRepository.save(loginUser);
		details.setLoginUser(loginUser);
		loginUserDetailsRepository.save(details);
		return "Details Saved Successfully";
		
	}
	
}

package com.sai.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sai.dto.RegisterRequest;
import com.sai.dto.RegisterResponse;
import com.sai.service.RegisterUserService;

@RestController
@RequestMapping("register")
public class RegisterController {
	
	@Autowired
	private RegisterResponse response;
	
	@Autowired
	private RegisterUserService service;
	
	@RequestMapping(path = {"verify"}, method = {RequestMethod.POST})
	public RegisterResponse validate(@RequestBody RegisterRequest request) {
		
		String result = service.registerUser(request);
		response.setMessage(result);
		return response;
		
	}

}

package com.sai.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sai.dto.ValidateRequest;
import com.sai.dto.ValidateResponse;
import com.sai.service.LoginUserService;

@RestController
@RequestMapping("login")
public class LoginController {
	
	@Autowired
	private ValidateResponse response;
	
	@Autowired
	private LoginUserService service;
	
	@RequestMapping(path = {"validate"}, method = {RequestMethod.POST})
	public ValidateResponse validate(@RequestBody ValidateRequest request) {
		
		String result = service.validateUser(request);
		response.setMessage(result); 
		return response;
		
	}

}

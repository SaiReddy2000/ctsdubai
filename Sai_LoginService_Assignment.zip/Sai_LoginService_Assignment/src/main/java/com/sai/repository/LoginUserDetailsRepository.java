package com.sai.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.entity.LoginUserDetails;

@Repository
public interface LoginUserDetailsRepository extends JpaRepository<LoginUserDetails, Integer> {

}

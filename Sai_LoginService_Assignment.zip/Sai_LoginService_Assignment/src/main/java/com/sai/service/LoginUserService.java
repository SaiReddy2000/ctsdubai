package com.sai.service;

import com.sai.dto.ValidateRequest;

public interface LoginUserService {

	String validateUser(ValidateRequest request);

}
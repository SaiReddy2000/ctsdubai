package com.sai.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.dao.LoginUserDAO;
import com.sai.dto.ValidateRequest;
import com.sai.entity.LoginUser;

@Service
public class LoginUserServiceImpl implements LoginUserService {

	@Autowired
	private LoginUserDAO dao;

	@Override
	public String validateUser(ValidateRequest request) {

		Integer loginId = request.getUserId();
		Optional<LoginUser> optional = dao.getUser(loginId);
		if (optional.isPresent()) {
			LoginUser loginUser = optional.get();
			if (loginUser.getLoginId().equals(request.getUserId())
					&& loginUser.getPassword().equals(request.getPassword())) {
				return "Welcome: " + loginUser.getLoginUserDetails().getFirstName() + " " + loginUser.getLoginUserDetails().getLastName() + "," + "Type of User: " + loginUser.getType();
			} else {
				return "Password is Wrong";
			}
		}
		return "User ID is Wrong";
	}

}

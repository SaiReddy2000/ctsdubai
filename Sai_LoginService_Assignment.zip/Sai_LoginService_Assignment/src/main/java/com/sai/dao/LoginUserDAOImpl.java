package com.sai.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sai.entity.LoginUser;
import com.sai.repository.LoginUserRepository;

@Repository
public class LoginUserDAOImpl implements LoginUserDAO {
	
	@Autowired
	private LoginUserRepository loginUserRepository;

	@Override
	public Optional<LoginUser> getUser(Integer loginId) {
		
		return loginUserRepository.findById(loginId);
		
	}
	
}

package com.sai.dao;

import java.util.Optional;

import com.sai.entity.LoginUser;

public interface LoginUserDAO {

	Optional<LoginUser> getUser(Integer loginId);

}